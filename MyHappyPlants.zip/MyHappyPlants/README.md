# My Happy Plants (Team 24)

Delaktiga:
Viktor Johansson, 
Aida Muratagic,
Fanny Rosdahl Rosenglim,
Hatem Ali Hussein,
Erik Hedåker

Projektbeskrivning:
My Happy Plants, en desktopapplikation som går ut på att hjälpa användaren att ta hand om blommor/växter.
Tanken är att applikationen ska underlätta i vardagen med notiser, en tydlig lista över växtinnehav 
och att göra det möjligt för användaren att följa sina växter. 

Användning: Programmet kan köras på både Windows & Mac men är mer optimerat för Windows. Ifall du handlat en ny växt 
så kan du lägga in den i appen genom att söka på växtens namn. Där presenteras växten med information som kan vara nödvändig 
för ägare av växten. Ifall användaren sedan klickar på "Lägg till" knappen så kommer användaren till en 
sida där man kan specificera information om växten (t.ex. storlek, miljö). Detta bidrar till att programmet sedan kan räkna ut när 
det kan vara rimligt att vattna växten. Därefter klickar du på "Spara" knappen, och växten lägger sig på listan i startsidan. 

Länk Github: https://github.com/ErikHedaker/MyHappyPlants.git
