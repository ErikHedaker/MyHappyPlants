package view.panels.login;

public enum LoginStatus {
    REGISTER_PAGE,
    LOGIN_PAGE;
}
